package io.jenkins.plugins.pipeline.lib.oras.vars

def call() {
    echo "This is myFunc from the oras library"
}